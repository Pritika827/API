package com.task.employee.eo;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.task.employee.dao.EmployeeDao;
import com.task.employee.model.EmployeeDto;
@Component
public class EmployeeEoImpl implements EmployeeEo {
	@Autowired
	private EmployeeDao employeeDao;
	
	
	Logger logger=LoggerFactory.getLogger(EmployeeEo.class);
	
	@Override
	public EmployeeDto addEmployeeDto(EmployeeDto employeeDto) {
		logger.info("adding employee details");
		System.out.println("EmployeeEoImpl class -> " +employeeDto);
		return employeeDao.addEmployeeDto(employeeDto);
	}


	  
	@Override
	public List<EmployeeDto> getEmployeeDto() {
	    logger.info("get all employees");
	    List<EmployeeDto> employeeDtoList = employeeDao.getEmployeeDto();
	    return employeeDtoList;
	}

	}
	
	

