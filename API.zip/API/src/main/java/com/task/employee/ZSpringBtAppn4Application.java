package com.task.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages= "com.task.employee.mapper")
public class ZSpringBtAppn4Application {

	public static void main(String[] args) {
		SpringApplication.run(ZSpringBtAppn4Application.class, args);
	}

}
